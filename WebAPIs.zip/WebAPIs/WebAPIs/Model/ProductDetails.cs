namespace WebAPIs
{
    public class ProductDetails
    {
        public int ProductId { get; set; }

        public string Name { get; set; }

        public DateTime ExpiryDate { get; set; }

        public string CategoryName { get; set; }

        public string Color { get; set; }

        public DateTime DateAdded { get; set; }

        public DateTime? DateUpdated { get; set; }
    }
}