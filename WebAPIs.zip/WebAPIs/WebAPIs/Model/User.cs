namespace WebAPIs
{
    public class User
    {
        public string Name{ get; set; }

        public string Password { get; set; }
    }
}