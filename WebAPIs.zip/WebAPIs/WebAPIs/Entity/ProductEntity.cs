using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

namespace WebAPIs
{
    public class ProductEntity
    {
        [Key]
        public int ProductId { get; set; }

        public string Name{ get; set; }

        public DateTime ExpiryDate { get; set; }
        
        public int CategoryId { get; set; }

        public string Color { get; set; }

        public DateTime DateAdded { get; set; }

        public DateTime? DateUpdated { get; set; }

        public CategoryEntity Category { get; set; }
    }
}