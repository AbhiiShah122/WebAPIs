using System.ComponentModel.DataAnnotations;

namespace WebAPIs
{
    public class CategoryEntity
    {
        [Key]
        public int CategoryId { get; set; }
        public string Name{ get; set; }
        public ProductEntity Product{ get; set; }
    }
}