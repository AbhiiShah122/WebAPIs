using Microsoft.AspNetCore.Mvc;
using WebAPIs.Repository;

namespace WebAPIs.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ProductController : ControllerBase
    {
        private readonly ILogger<LoginController> _logger;
        private readonly IProductRepository _productRepository;

        public ProductController(ILogger<LoginController> logger, IProductRepository productRepository)
        {
            _logger = logger;
            _productRepository = productRepository;
        }

        [HttpPost(Name = "AddProduct")]
        public async Task<IActionResult> AddProduct([FromBody] Product product)
        {
            var productEntity = new ProductEntity
            {
                Name = product.Name,
                ExpiryDate = product.ExpiryDate,
                CategoryId = product.CategoryId,
                Color = product.Color,
                DateAdded = DateTime.UtcNow,
                DateUpdated = null
            };
            var successResult = await _productRepository.AddProduct(productEntity);

            if (successResult)
            {
                return Created("", new { ProductId = productEntity.ProductId });
            }
            return BadRequest();
        }

        [HttpPut(Name = "UpdateProduct/{productId}")]
        public async Task<IActionResult> UpdateProduct(int productId, [FromBody] Product product)
        {
            var productEntity = new ProductEntity
            {
                ProductId = productId,
                Name = product.Name,
                ExpiryDate = product.ExpiryDate,
                CategoryId = product.CategoryId,
                Color = product.Color,
                DateUpdated = DateTime.UtcNow
            };
            var successResult = await _productRepository.UpdateProduct(productEntity);

            if (successResult)
            {
                return Ok(productEntity);
            }
            return BadRequest();
        }

        [HttpGet(Name = "GetProduct/{productId}")]
        public async Task<IActionResult> GetProduct(int productId)
        {
            var productDetails = await _productRepository.GetProduct(productId);

            if (productDetails != null)
            {
                return Ok(productDetails);
            }
            return NotFound();
        }
    }
}