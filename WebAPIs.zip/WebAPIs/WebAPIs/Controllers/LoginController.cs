using Microsoft.AspNetCore.Mvc;
using WebAPIs.Repository;

namespace WebAPIs.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class LoginController : ControllerBase
    {
        private readonly ILogger<LoginController> _logger;
        private readonly IUserRepository _userRepository;

        public LoginController(ILogger<LoginController> logger, IUserRepository userRepository)
        {
            _logger = logger;
            _userRepository = userRepository;
        }

        [HttpPost(Name = "SignUpUser")]
        public async Task<IActionResult> SignUp([FromBody] User user)
        {
            var userEntity = new UserEntity
            {
                Name = user.Name,
                Password = user.Password
            };

            var successResult = await _userRepository.SignUpUser(userEntity);

            if (successResult)
            {
                return Created("", user);
            }
            return BadRequest();
        }
    }
}