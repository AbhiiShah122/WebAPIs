﻿using Microsoft.EntityFrameworkCore;

namespace WebAPIs.Repository
{
    public class ProductRepository : IProductRepository
    {
        private readonly ProductContext _productContext;

        public ProductRepository(ProductContext productContext)
        {
            _productContext = productContext;
        }

        public async Task<Boolean> AddProduct(ProductEntity product)
        {
            try
            {
                await _productContext.AddAsync(product);
                var result = await _productContext.SaveChangesAsync();
                return result > 0;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public async Task<Boolean> UpdateProduct(ProductEntity productEntity)
        {
            try
            {
                var product = await _productContext.Product.FirstOrDefaultAsync(pro => pro.ProductId == productEntity.ProductId);
                if (product != null)
                {
                    var updatedProduct = productEntity;
                    updatedProduct.DateAdded = product.DateAdded;
                    _productContext.Entry(product).State = EntityState.Detached;
                    _productContext.Update(updatedProduct);
                    var result = await _productContext.SaveChangesAsync();
                    return result > 0;
                }
                return false; 
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public async Task<ProductDetails?> GetProduct(int productId)
        {
            try
            {
                return await _productContext.Product.Join(
                    _productContext.Category,
                    product => product.ProductId,
                    category => category.CategoryId,
                    (product, category) => new ProductDetails
                    {
                        ProductId = product.ProductId,
                        Name = product.Name,
                        ExpiryDate = product.ExpiryDate,
                        CategoryName = category.Name,
                        Color = product.Color,
                        DateAdded = product.DateAdded,
                        DateUpdated = product.DateUpdated
                    }
                    )
                    .Where(product => product.ProductId == productId)
                    .FirstOrDefaultAsync();
            }
            catch (Exception ex)
            {
                return null;
            }
        }
    }

    public interface IProductRepository
    {
        Task<Boolean> AddProduct(ProductEntity product);

        Task<Boolean> UpdateProduct(ProductEntity product);

        Task<ProductDetails> GetProduct(int productId);
    }
}
