﻿namespace WebAPIs.Repository
{
    public class UserRepository : IUserRepository
    {
        private readonly ProductContext _productContext;

        public UserRepository(ProductContext productContext)
        {
            _productContext = productContext;
        }

        public async Task<Boolean> SignUpUser(UserEntity user)
        {
            try
            {
                await _productContext.AddAsync(user);
                var result = await _productContext.SaveChangesAsync();
                return result > 0;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }

    public interface IUserRepository
    {
        Task<Boolean> SignUpUser(UserEntity user);
    }
}
