using Microsoft.EntityFrameworkCore;

namespace WebAPIs
{
    public class ProductContext : DbContext
    {
        public ProductContext(DbContextOptions<ProductContext> options) : base(options)
        { }
        
        public DbSet<UserEntity> User { get; set; }

        public DbSet<ProductEntity> Product { get; set; }

        public DbSet<CategoryEntity> Category { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        { 
            base.OnModelCreating(builder);

            builder.Entity<ProductEntity>()
                .Property(e => e.ProductId)
                .ValueGeneratedOnAdd();

            builder.Entity<UserEntity>()
                .Property(e => e.UserId)
                .ValueGeneratedOnAdd();

            builder.Entity<ProductEntity>()
                .HasOne(p => p.Category)
                .WithOne(c => c.Product)
                .HasForeignKey<ProductEntity>(p => p.CategoryId);

            builder.Entity<CategoryEntity>()
                .HasData(
                new CategoryEntity { CategoryId = 1 , Name = "Electric" },
                new CategoryEntity { CategoryId = 2, Name = "Commodity" }, 
                new CategoryEntity { CategoryId = 3, Name = "Clothing" }
                );
        }
    }
}